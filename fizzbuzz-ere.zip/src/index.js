var num = 1;
var limit = 101;

if ((num = num)) {
  console.log((num = num + 1));
}

if (num % 15 == 0) {
  console.log("FizzBuzz");
} else if (num % 3 == 0) {
  console.log("Fizz");
} else if (num % 5 == 0) {
  console.log("Buzz");
} else if (num === limit) {
  console.log("listo");
} else {
  console.log;
}
